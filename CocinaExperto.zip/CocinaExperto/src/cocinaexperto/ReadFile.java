/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cocinaexperto;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USUARIO
 */
public class ReadFile {
    String lsContent;


    
    public String getLsContent() {
        return lsContent;
    }

    public void setLsContent(String lsContent) {
        this.lsContent = lsContent;
    }
    
    
    
    public void processFile(String path) throws FileNotFoundException, IOException
    {
      String line;
      StringBuilder lsbContent =  new StringBuilder();
      FileReader f = new FileReader(path);
      BufferedReader b = new BufferedReader(f);
      while((line = b.readLine())!=null) {
          //System.out.println(line);
          lsbContent.append(line +"\n");
      }
      b.close();
      setLsContent(lsbContent.toString());
      lsbContent = null; 
    }
    
}
