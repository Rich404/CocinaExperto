/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cocinaexperto;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author USUARIO
 */
public class CocinaExperto {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException 
    {
        CocinaExperto loCocicaEx =  new CocinaExperto();
        
        //  *** Creando Objetos y Mapas de Datos  **** //
        String lsFullStringSource = null;
        lsFullStringSource =  loCocicaEx.getDBPData("RegionDBP.txt");
        Entity leRegion = new Entity("Region",new String []{"id_region","nombre_region"}, lsFullStringSource);
        leRegion.generateMap();
     
        lsFullStringSource = null;
        lsFullStringSource =  loCocicaEx.getDBPData("Estados_RegionDBP.txt");
        Entity leEstados = new Entity("Estados",new String []{"id_estado","nombre_estado","id_region"}, lsFullStringSource);
        leEstados.generateMap();
        
        lsFullStringSource = null;
        lsFullStringSource =  loCocicaEx.getDBPData("CarnesBDP.txt");
        Entity leCarnes = new Entity("Carnes",new String []{"id_carne","nombre_carne"}, lsFullStringSource);
        leCarnes.generateMap();
        
        
        lsFullStringSource = null;
        lsFullStringSource =  loCocicaEx.getDBPData("IngredientesDBP.txt");
        Entity leIngredientes = new Entity("Ingredientes",new String []{"id_ingrediente","nombre_ingrediente"}, lsFullStringSource);
        leIngredientes.generateMap();
        
        lsFullStringSource = null;
        lsFullStringSource =  loCocicaEx.getDBPData("PlatillosDBP.txt");
        Entity lePlatillos = new Entity("Platillos",new String []{"id_platillo","nombre_platillo","id_carne","precio","id_estado"}, lsFullStringSource);
        lePlatillos.generateMap();
        
        lsFullStringSource = null;
        lsFullStringSource =  loCocicaEx.getDBPData("PlatillosIngredientes.txt");
        Entity leIngredPlatillos = new Entity("PlatillosIngrdientes",new String []{"id_platillo","id_ingrediente"}, lsFullStringSource);
        leIngredPlatillos.generateMap();
        
        // Ok incia logica //
        
        String lsResponse = loCocicaEx.getResponseJoptionCombo(leRegion.getArrayOptions("nombre_region")," Hola  bienvenido ! \n  Por favor escoja una region del país . ");
        String lsRegionId = leRegion.findKey("nombre_region", lsResponse,"id_region");
        System.out.println(lsRegionId);
        
        lsResponse = null;
        lsResponse = loCocicaEx.getResponseJoptionCombo(leEstados.getArrayByKey("id_region",lsRegionId,"nombre_estado"), " Elija un Estado de la Region");
        String lsEstadoId = leEstados.findKey("nombre_estado", lsResponse,"id_estado");
        System.out.println(lsEstadoId);
        
        lsResponse = null;
        Object [] loRespPlatillosByEstado = lePlatillos.getArrayByKey("id_estado", lsEstadoId,"id_platillo");// Id Por Estado
        Object [] loRespCarnePlatillosByEdtado = lePlatillos.getArrayByKey("id_estado", lsEstadoId,"id_carne");
        
        
        lsResponse = null;
        lsResponse = loCocicaEx.getResponseJoptionCombo(leCarnes.getKeys("id_carne", loRespCarnePlatillosByEdtado ,"nombre_carne"), " La proteina ocupada es : ");
        String lsCarneId =  leCarnes.findKey("nombre_carne", lsResponse,"id_carne");
        System.out.println(lsCarneId);
        
        Object [] loRespPlatillosByCarne = lePlatillos.getArrayByKey("id_carne", lsCarneId, "id_platillo");// ID's Definitivos por Carne
        
       
        
        lsResponse = null;
        Object [] loaIngredientes =  loCocicaEx.getResponseJOptionCheckCombo(leIngredientes.getArrayOptions("nombre_ingrediente"));
        System.out.println(Arrays.toString(loaIngredientes)); 
        Object [] loaIndexIngredientes =  leIngredientes.getKeys("nombre_ingrediente",loaIngredientes,"id_ingrediente");
        System.out.println(Arrays.toString(loaIndexIngredientes));
        
        
        
        for (Object loaIndexIngrediente : loaIndexIngredientes) {
            for (int i = 0; i < leIngredPlatillos.msMap.get("id_ingrediente").size(); i++) {
                if(leIngredPlatillos.msMap.get("id_ingrediente").get(i).equals(loaIndexIngrediente))
                { 
                    System.out.println("Region: " + lsRegionId  + " Estado:"+ lsEstadoId +"Carnes:" + lsCarneId);
                    System.out.println(leIngredPlatillos.msMap.get("id_platillo").get(i) +" Index Key: " +lePlatillos.msMap.get("id_platillo").indexOf(leIngredPlatillos.msMap.get("id_platillo").get(i)));
                    int IndexKey = lePlatillos.msMap.get("id_platillo").indexOf(leIngredPlatillos.msMap.get("id_platillo").get(i));
                    //lePlatillos.viewDataForResult(new String []{"id_platillo","nombre_platillo","id_carne","precio","id_estado"}, IndexKey);
                    
                    if(lePlatillos.msMap.get("id_estado").get(IndexKey).equals(lsEstadoId) && lePlatillos.msMap.get("id_carne").get(IndexKey).equals(lsCarneId))
                    {
                        System.out.println(" OK  Encontrado ---"+ leIngredPlatillos.msMap.get("id_platillo").get(i));
                        lePlatillos.viewDataForResult(new String []{"id_platillo","nombre_platillo","id_carne","precio","id_estado"}, IndexKey);
                    }
                    
                }
            }
        }
        
        
        
    }
    
    public String getDBPData(String lsPath)
    {
        ReadFile loStringFile  =  new ReadFile();
        try {
            loStringFile.processFile(lsPath);
        } catch (IOException ex) {
            Logger.getLogger(CocinaExperto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return loStringFile.lsContent;
    }
    
    public String getResponseJoptionCombo(Object  []lsOptions,String lsQuestion)
    {
            Object loResponse = JOptionPane.showInputDialog(null,lsQuestion,"Cocina", JOptionPane.QUESTION_MESSAGE, null,lsOptions,"Seleccione");
            if( loResponse == null )
            {
                System.exit(0);
            }
            return loResponse.toString();
    }
    
    public Object [] getResponseJOptionCheckCombo (Object []lasValues)
    {
        JList lolist = new JList(lasValues);
        JOptionPane.showMessageDialog(null, lolist, "Seleccione los ingredientes:  (Ctrl + Click) ", JOptionPane.QUESTION_MESSAGE);
        System.out.println(Arrays.toString(lolist.getSelectedIndices()));
        //return lolist.getSelectedIndices();
        return lolist.getSelectedValues();
    }
   
}
