/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cocinaexperto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

/**
 *
 * @author HpAdmin
 */
public class Entity {
    
    String msEntityName ;
    String [] lsFields ;
    String lsFullDataString;
    Map<String,ArrayList<String>> msMap = new HashMap<>();

    public Entity(String msEntityName, String[] lsFields, String lsFullDataString) {
        this.msEntityName = msEntityName;
        this.lsFields = lsFields;
        this.lsFullDataString = lsFullDataString;
    }
    
    public void viewDataForResult (String lsFields[],int index)
    {
        for (String lsField : lsFields) {
            System.err.print(msMap.get(lsField).get(index) + "\t");
        }
        System.out.println("\n\n");
    }
    
    
    public void generateMap ()
    {
        initMap();
        ArrayList<String> lasDataByLine = getArrayStringByDelimiter(lsFullDataString,"\n");// Obtener linea por linea
        for (String lsDataItem : lasDataByLine) {  
            ArrayList<String> lasDataByPipe = getArrayStringByDelimiter(lsDataItem,"\\|");// obtener por pipe o por columna
            int index = 0;// index para los items
            for (int j = 0; j < lsFields.length; j++) {
                msMap.get(lsFields[j]).add(lasDataByPipe.get(index));
                index++;
            }
        }
        
        viewMap();
        
    }
    
    public void initMap ()
    {
        for (int j = 0; j < lsFields.length; j++) {
            ArrayList<String> las = new ArrayList<>();
            msMap.put(lsFields[j],las);
        }
        viewMap();
    }
    public void viewMap()
    {
        System.out.println("MAPA  "+ msEntityName +": " +  msMap.toString() + " \n Tamaño: " + msMap.size());
    }
    
    
    public ArrayList<String> getArrayStringByDelimiter (String lsData,String lsDelimiter)
    {   
        ArrayList<String> lasData =  new ArrayList<>();
        StringTokenizer lsToken =  new StringTokenizer(lsData,lsDelimiter);
        while(lsToken.hasMoreTokens()) {
            lasData.add(lsToken.nextToken());
        }
        return  lasData;
    }
    
    public Object [] getArrayOptions (String lsField)
    {
            return  msMap.get(lsField).toArray();
    }
    
    public String findKey(String lsKey,String lsValue,String lsKeyForFind)
    {
        ArrayList<String> lasTmpAray = msMap.get(lsKey);// Obteniendo posicion de valor
        int index = lasTmpAray.indexOf(lsValue);
        if(index != -1)
        {
             return  msMap.get(lsKeyForFind).get(index);
        }
        else
        {
            return  "Error";
        }
        
    }
    
    public Object[] getArrayByKey(String lsKey,String lsValue,String lsKeyForFind)
    {
        ArrayList<String> lasFoundArray =  msMap.get(lsKey);
        ArrayList<String> lasForResult =  new ArrayList<>();
        for (int i = 0; i < lasFoundArray.size(); i++) {
            if(lasFoundArray.get(i).equals(lsValue))
            {
                System.out.println("Esta en la posicion: "+ i);
                lasForResult.add(msMap.get(lsKeyForFind).get(i));
            }
        }
        return lasForResult.toArray();
    }
    
    public Object[] getKeys(String lsKey,Object [] lsValues,String lsKeyForFind)
    {
        Object [] loaResult = new Object[lsValues.length];
        for (int i = 0; i < lsValues.length; i++) {
            loaResult [i] = findKey(lsKey, lsValues[i].toString(), lsKeyForFind);
        }
        return  loaResult;
    }
    
    
}
