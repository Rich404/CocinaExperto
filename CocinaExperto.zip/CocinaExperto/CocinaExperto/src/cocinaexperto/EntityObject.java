/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cocinaexperto;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author TICS
 */
public class EntityObject extends  ArrayList<String> {

    String [] msFields  ;

    public EntityObject(String [] lsFields) {
        msFields = lsFields;
    }
   

    public void viewData()
    {
        for (int i = 0; i < size(); i++) {
            System.out.println(" Data: "  +  get(i));
        }
    }
}
