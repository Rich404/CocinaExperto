/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cocinaexperto;

import java.util.ArrayList;

/**
 *
 * @author TICS
 */
public class EntityObjectArray extends ArrayList {
    String msEntityName;

    public EntityObjectArray(String lsEntityName) {
        msEntityName = lsEntityName;
    }

    public String getMsEntityName() {
        return msEntityName;
    }

    public void setMsEntityName(String msEntityName) {
        this.msEntityName = msEntityName;
    }
    
}
