/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cocinaexperto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class CocinaExperto {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        CocinaExperto loCocicaEx =  new CocinaExperto();
        // Datos  de Region . 
        String lsRagionData  =  loCocicaEx.getDBPData("C:\\Users\\TICS\\Desktop\\CocinaExperto\\RegionDBP.txt");
        ArrayList<String> lasData = loCocicaEx.getArrayStringData(lsRagionData,"\n");
        ArrayList<Region> loArrayRegion = new ArrayList<>();
        
        for (int i = 0; i < lasData.size(); i++) {
            
            ArrayList<String> loArray  = loCocicaEx.getArrayStringData(lasData.get(i),"\\|");
            Region loRegion =  new Region();
            loRegion.setIdRegion(loArray.get(0));
            loRegion.setRegionName(loArray.get(1));
            loArrayRegion.add(loRegion);
            
        }
        loArrayRegion.get(0).viewData();
         loArrayRegion.get(2).viewData();
    }
    
    public ArrayList<String> getArrayStringData (String lsData,String lsDelimiter)
    {   
        ArrayList<String> lasData =  new ArrayList<>();
        StringTokenizer lsToken =  new StringTokenizer(lsData,lsDelimiter);
        while(lsToken.hasMoreTokens()) {
            lasData.add(lsToken.nextToken());
        }
        return  lasData;
    }
    
    public String getDBPData(String lsPath)
    {
        ReadFile loStringFile  =  new ReadFile();
        try {
            loStringFile.processFile(lsPath);
        } catch (IOException ex) {
            Logger.getLogger(CocinaExperto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return loStringFile.lsContent;
    }
    
    public String getResponseJoptionCombo()
    {
            Object loResponse = JOptionPane.showInputDialog(null,"Cocina XYZ ","Cocina", JOptionPane.QUESTION_MESSAGE, null,new Object[] { "Seleccione","Amarillo", "Azul", "Rojo" },"Seleccione");
            if( loResponse == null )
            {
                System.exit(0);
            }
            return loResponse.toString();
    }
}
