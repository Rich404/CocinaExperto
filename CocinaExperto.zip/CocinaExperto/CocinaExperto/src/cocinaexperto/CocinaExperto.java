/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cocinaexperto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author USUARIO
 */
public class CocinaExperto {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        CocinaExperto loCocicaEx =  new CocinaExperto();
        
        EntityObjectArray lasRegion  = loCocicaEx.geEntryArray("C:\\Users\\TICS\\Desktop\\CocinaExperto\\RegionDBP.txt","Region",new String[]{"Id","Name"});
        loCocicaEx.getResponseJoptionCombo(loCocicaEx.getVectorArrayFromArrayEntity(lasRegion,0),"Cocina la Tía , Tenemos las sig. Regiones ");
        
        EntityObjectArray lasEstados  =  loCocicaEx.geEntryArray("C:\\Users\\TICS\\Desktop\\CocinaExperto\\Estados_RegionDBP.txt","Estados",new String[]{"Id","Name","Region"});
        loCocicaEx.getResponseJoptionCombo(loCocicaEx.getVectorArrayFromArrayEntity(lasEstados,1),"Estados");
        
        
        /* Datos  de Region . 
        String lsRagionData  =  loCocicaEx.getDBPData("C:\\Users\\TICS\\Desktop\\CocinaExperto\\RegionDBP.txt");
        ArrayList<String> lasData = loCocicaEx.getArrayStringData(lsRagionData,"\n");
        ArrayList<Region> loArrayRegion = new ArrayList<>();
        
        for (int i = 0; i < lasData.size(); i++) {
            
            ArrayList<String> loArray  = loCocicaEx.getArrayStringData(lasData.get(i),"\\|");
            Region loRegion =  new Region();
            loRegion.setIdRegion(loArray.get(0));
            loRegion.setRegionName(loArray.get(1));
            loArrayRegion.add(loRegion);
            
        }
        loArrayRegion.get(0).viewData();
         loArrayRegion.get(2).viewData();*/
    }
    
    
    private String[] getVectorArrayFromArrayEntity(  EntityObjectArray lasArrayEntity,int liField)
    {
        String[] lasString =  new String[lasArrayEntity.size()];
        for (int i = 0; i < lasArrayEntity.size(); i++) {
            EntityObject x = (EntityObject) lasArrayEntity.get(i);
            lasString[i] = x.get(liField);
            
        }      
        return lasString;
    }
    
    public EntityObjectArray geEntryArray(String lsPath,String lsEntity,String []lsFields)
    {
        String lsDBPData  =  getDBPData(lsPath);
        ArrayList<String> lasDataByLineJump = getArrayStringData(lsDBPData,"\n");// Array linea por linea \n
        EntityObjectArray lasEOARegion = new EntityObjectArray(lsEntity);
        for (int i = 0; i < lasDataByLineJump.size(); i++) {
            ArrayList<String> lasDataByPipe = getArrayStringData(lasDataByLineJump.get(i),"\\|");
            EntityObject losEntity=  new EntityObject(lsFields);
            losEntity.add(lasDataByPipe.get(0));
            losEntity.add(lasDataByPipe.get(1));
            lasEOARegion.add(losEntity);
        }
        
        return lasEOARegion;
    }
    
    public ArrayList<String> getArrayStringData (String lsData,String lsDelimiter)
    {   
        ArrayList<String> lasData =  new ArrayList<>();
        StringTokenizer lsToken =  new StringTokenizer(lsData,lsDelimiter);
        while(lsToken.hasMoreTokens()) {
            lasData.add(lsToken.nextToken());
        }
        return  lasData;
    }
    
    public String getDBPData(String lsPath)
    {
        ReadFile loStringFile  =  new ReadFile();
        try {
            loStringFile.processFile(lsPath);
        } catch (IOException ex) {
            Logger.getLogger(CocinaExperto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return loStringFile.lsContent;
    }
    
    public String getResponseJoptionCombo(Object  []lsOptions,String lsQuestion)
    {
            Object loResponse = JOptionPane.showInputDialog(null,lsQuestion,"Cocina", JOptionPane.QUESTION_MESSAGE, null,lsOptions,"Seleccione");
            if( loResponse == null )
            {
                System.exit(0);
            }
            return loResponse.toString();
    }
}
