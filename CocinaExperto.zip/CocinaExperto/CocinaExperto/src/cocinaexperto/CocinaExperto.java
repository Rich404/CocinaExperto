/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cocinaexperto;

import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author USUARIO
 */
public class CocinaExperto {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        CocinaExperto loCocicaEx =  new CocinaExperto();
        String lsRagionData  =  loCocicaEx.getDBPData("C:\\Users\\USUARIO1\\Desktop\\RegionDBP.txt");
        System.out.println( " Bruto \n" + lsRagionData);
        ArrayList<String> lasDataRegion = loCocicaEx.getArrayStringData(lsRagionData,"\n");
        
        
        for (String string : lasDataRegion) {
            
            System.out.println(" Items into Array: " + string);
        }
        
    }
    
    public ArrayList<String> getArrayStringData (String lsData,String lsDelimiter)
    {   
        ArrayList<String> lasData =  new ArrayList<>();
        StringTokenizer lsToken =  new StringTokenizer(lsData,lsDelimiter);
        while(lsToken.hasMoreTokens()) {
            lasData.add(lsToken.nextToken());
        }
        return  lasData;
    }
    
    public String getDBPData(String lsPath)
    {
        ReadFile loStringFile  =  new ReadFile();
        try {
            loStringFile.processFile(lsPath);
        } catch (IOException ex) {
            Logger.getLogger(CocinaExperto.class.getName()).log(Level.SEVERE, null, ex);
        }
        return loStringFile.lsContent;
    }
    
}
